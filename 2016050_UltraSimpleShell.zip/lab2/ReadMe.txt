
source - https://brennan.io/2015/01/16/write-a-shell-in-c/

We continue in a while loop wherein we take the entire line input from the user and then split the string into tokens using strtok()
for all valid separator types. 

Then check if the command is the direct type. ie; if it is exit or kill - exit the process and if it is cd then check for the next argument.

for other commands such as 'ls' we can copy the process using fork so  that it becomes a child process and then replace it with the process requested through the terminal using execvp();

