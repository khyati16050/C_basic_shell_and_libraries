#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>
//khyati seth
int main()
{
	while(1) //infinite loop
	{
		char *new_line = NULL;
		char **tokens = NULL; //string of strings - double pointer
		int index = -1;
		char *separate;
		printf("TERMINAL >> ");
		ssize_t size = 0;
		getline(&new_line, &size, stdin);
	  	tokens = malloc(128 *sizeof(char*));
		int token = 1; 
		separate = strtok(new_line," \t\r\n\a"); //takes all the types of separators into account so that we can enter different types of commands.
		while (separate != NULL) //while there is no null argument	
		{
			index++; 
			tokens[index] = separate;
			separate = strtok(NULL," \t\r\n\a");
		}
		
		index++;
		tokens[index]=NULL;
		if(tokens[0]==NULL) //if there is no command enetered then continue giving the "TERMINAL >> " message
			continue;
		else
		{	
			token = 0;
			if(strcmp("exit",tokens[0]) == 0) //direct command
				return 0;	
			else if(strcmp("cd",tokens[0]) == 0) //direct command
			{
				if(tokens[1]!=NULL) //ie; cd is true
				{	
					if(chdir(tokens[1])!=0) 
					{
						printf("ERROR\n");
						continue;
					}
					
				}
				else //if there is a null argument after cd
				{
					printf("NO VALID ARGUMENT\n");
				}
			}
			else if(strcmp("kill", tokens[0]) == 0) //using kill as an exit function 
				return 0;	
			else
			{	// source -  https://brennan.io/2015/01/16/write-a-shell-in-c/
				int status;
				pid_t child;
				pid_t temp; 
			child = fork(); //divides into two processes  -- copies the process
				if(child<0)
					printf("ERROR\n");
				else if(child>0)
				{
				    while(1) //infinite loop
					{
						temp  = waitpid(child,&status,WUNTRACED);
						if(WIFEXITED(status) || WIFSIGNALED(status))  // source -  https://brennan.io/2015/01/16/write-a-shell-in-c/
							break;
					}
				}
				else
				{
					

					if (execvp(tokens[0],tokens)==-1)  //sends the programme to the terminal. ie; replaces the copied process by the process requested in the terminal
					      printf("ERROR\n");
					exit(EXIT_FAILURE);
				}
				
				
			}
		}
		
	}


	return 0;
}
