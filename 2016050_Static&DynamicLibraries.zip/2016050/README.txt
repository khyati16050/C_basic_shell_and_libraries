char *strcpy(char *dest, const char *src);

We create a char *finalstring = dest. then,the first condition that we see is if the destintion 
or the source string is null or not. if any of them is null , we ask the user for a different input.
if none are null, we continue in a while loop where until *src is not null we equte *dest and src so tht we copy the entire string until it is null terminated.
then we assign NULL to dest and return final string that we had created. This now has the entire %NUL terminated string.


char *strcat(char *dest, const char *src);

We create a char *finalstring = dest. then,the first condition that we see is if the destintion 
In this if none of the destination nor the source strings are NULL , we continue to append src to dest by doing *dest++ = *src++
this adds the destination string to the last chracter of the source string. we then return the final string.

char *my_strncat(char *dest, const char *src, int count)









